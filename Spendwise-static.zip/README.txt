Spendwise - static build

Open index.html in a browser, or serve with any static server (python -m http.server, node serve-dist.mjs, etc.).

Android APK: host it (e.g. GitHub Pages/Netlify) and use PWA Builder (https://www.pwabuilder.com/) to generate an APK/AAB.

No backend. All data is stored locally in IndexedDB.