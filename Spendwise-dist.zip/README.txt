Open index.html in a modern browser, or serve this folder with any static server.

Android APK: use PWA Builder (https://www.pwabuilder.com/) with the site URL or upload this zip.

No server required.